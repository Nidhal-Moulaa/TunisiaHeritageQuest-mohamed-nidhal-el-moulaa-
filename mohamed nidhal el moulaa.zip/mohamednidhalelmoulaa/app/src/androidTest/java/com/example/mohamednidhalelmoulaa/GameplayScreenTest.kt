package com.example.mohamednidhalelmoulaa

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.mohamednidhalelmoulaa.data.GameRepository
import com.example.mohamednidhalelmoulaa.model.Difficulty
import com.example.mohamednidhalelmoulaa.ui.screens.GameplayScreen
import com.example.mohamednidhalelmoulaa.ui.theme.MohamedNidhalElMoulaaTheme
import com.example.mohamednidhalelmoulaa.viewmodel.GameViewModel
import org.junit.Rule
import org.junit.Test

class GameplayScreenTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `test answering question reveals fact and next button`() {
        val viewModel = GameViewModel()
        // Setup initial state
        viewModel.selectCategory(GameRepository.categories[0])
        viewModel.selectDifficulty(Difficulty.EASY)
        viewModel.startGame()

        composeTestRule.setContent {
            MohamedNidhalElMoulaaTheme {
                GameplayScreen(
                    viewModel = viewModel,
                    onGameOver = {}
                )
            }
        }

        val question = viewModel.uiState.value.currentQuestion!!
        
        // Assert that question text is displayed
        composeTestRule.onNodeWithText(question.text).assertExists()

        // Click the first option
        composeTestRule.onNodeWithText(question.options[0]).performClick()

        // Assert that the fact is now displayed
        composeTestRule.onNodeWithText("Did you know?\n${question.fact}").assertExists()
        
        // Assert that the 'Next Question' button is displayed
        composeTestRule.onNodeWithText("Next Question").assertExists()
    }
}
