package com.example.mohamednidhalelmoulaa

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.testing.TestNavHostController
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class NavigationTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun appNavigatesToCategorySelection() {
        lateinit var navController: TestNavHostController

        composeTestRule.setContent {
            navController = TestNavHostController(LocalContext.current)
            navController.navigatorProvider.addNavigator(ComposeNavigator())
            GameApp(navController = navController)
        }

        // Wait for Splash Screen to navigate automatically (not easy in standard UI tests without delay, so we skip directly testing splash delay and test MainMenu)
        // Actually, the Splash Screen has a LaunchedEffect with 2s delay.
        // It's better to test navigation from MainMenu to Category.
        // Let's force navigate to Main Menu to skip Splash wait
        composeTestRule.runOnUiThread {
            navController.navigate(Screen.MainMenu.name)
        }

        composeTestRule.onNodeWithText("Play Game").performClick()

        val route = navController.currentBackStackEntry?.destination?.route
        assertEquals(Screen.Category.name, route)
    }
}
