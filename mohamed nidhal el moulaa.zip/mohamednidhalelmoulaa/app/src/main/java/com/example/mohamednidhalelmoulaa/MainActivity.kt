package com.example.mohamednidhalelmoulaa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.mohamednidhalelmoulaa.ui.screens.CategorySelectionScreen
import com.example.mohamednidhalelmoulaa.ui.screens.DifficultySettingsScreen
import com.example.mohamednidhalelmoulaa.ui.screens.GameplayScreen
import com.example.mohamednidhalelmoulaa.ui.screens.MainMenuScreen
import com.example.mohamednidhalelmoulaa.ui.screens.ResultsScreen
import com.example.mohamednidhalelmoulaa.ui.screens.SplashScreen
import com.example.mohamednidhalelmoulaa.ui.theme.MohamedNidhalElMoulaaTheme
import com.example.mohamednidhalelmoulaa.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MohamedNidhalElMoulaaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    GameApp()
                }
            }
        }
    }
}

enum class Screen {
    Splash, MainMenu, Category, Difficulty, Gameplay, Results
}

@Composable
fun GameApp(
    navController: NavHostController = rememberNavController(),
    viewModel: GameViewModel = viewModel()
) {
    NavHost(navController = navController, startDestination = Screen.Splash.name) {
        composable(Screen.Splash.name) {
            SplashScreen(onNavigateToMain = {
                navController.navigate(Screen.MainMenu.name) {
                    popUpTo(Screen.Splash.name) { inclusive = true }
                }
            })
        }
        composable(Screen.MainMenu.name) {
            MainMenuScreen(onPlayClicked = {
                navController.navigate(Screen.Category.name)
            })
        }
        composable(Screen.Category.name) {
            CategorySelectionScreen(onCategorySelected = { category ->
                viewModel.selectCategory(category)
                navController.navigate(Screen.Difficulty.name)
            })
        }
        composable(Screen.Difficulty.name) {
            DifficultySettingsScreen(onDifficultySelected = { difficulty ->
                viewModel.selectDifficulty(difficulty)
                viewModel.startGame()
                navController.navigate(Screen.Gameplay.name) {
                    popUpTo(Screen.MainMenu.name) { inclusive = false }
                }
            })
        }
        composable(Screen.Gameplay.name) {
            GameplayScreen(
                viewModel = viewModel,
                onGameOver = {
                    navController.navigate(Screen.Results.name) {
                        popUpTo(Screen.Gameplay.name) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.Results.name) {
            val uiState by viewModel.uiState.collectAsState()
            ResultsScreen(
                score = uiState.score,
                totalQuestions = uiState.questions.size,
                difficulty = uiState.difficulty,
                onPlayAgain = {
                    viewModel.resetGame()
                    navController.navigate(Screen.Category.name) {
                        popUpTo(Screen.MainMenu.name) { inclusive = false }
                    }
                },
                onReturnToMenu = {
                    viewModel.resetGame()
                    navController.navigate(Screen.MainMenu.name) {
                        popUpTo(Screen.MainMenu.name) { inclusive = true }
                    }
                }
            )
        }
    }
}