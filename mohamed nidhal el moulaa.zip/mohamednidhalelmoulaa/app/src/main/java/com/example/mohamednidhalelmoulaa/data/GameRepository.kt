package com.example.mohamednidhalelmoulaa.data

import com.example.mohamednidhalelmoulaa.model.Category
import com.example.mohamednidhalelmoulaa.model.Question
import com.example.mohamednidhalelmoulaa.R

object GameRepository {
    val categories = listOf(
        Category(1, "Roman Heritage", "Discover the ancient Roman ruins and amphitheaters of Tunisia."),
        Category(2, "Islamic Heritage", "Explore the beautiful mosques and medinas."),
        Category(3, "Punic & Pre-Roman", "Uncover the secrets of Carthage and ancient civilizations."),
        Category(4, "Modern Heritage", "Learn about the modern history and mausoleums."),
        Category(5, "Natural Sites", "Experience the beautiful national parks and nature."),
        Category(6, "Cities", "Identify the vibrant cities of Tunisia.")
    )

    val romanHeritageQuestions = listOf(
        Question(
            id = 1,
            text = "Which of the following is the 3rd largest Roman amphitheater in the world?",
            options = listOf("Carthage Amphitheater", "El Jem Amphitheater", "Uthina Amphitheater", "Dougga Theater"),
            correctAnswerIndex = 1,
            categoryId = 1,
            fact = "The Amphitheatre of El Jem is capable of seating 35,000 spectators.",
            imageRes = R.drawable.el_jem
        ),
        Question(
            id = 2,
            text = "Which ancient Roman city is considered the best-preserved small Roman town in North Africa?",
            options = listOf("Sbeitla", "Bulla Regia", "Dougga", "Thuburbo Majus"),
            correctAnswerIndex = 2,
            categoryId = 1,
            fact = "Dougga was recognized as a UNESCO World Heritage Site in 1997.",
            imageRes = R.drawable.dogga
        ),
        Question(
            id = 3,
            text = "Which site is famous for its unique subterranean housing built to escape the heat?",
            options = listOf("Bulla Regia", "Utica", "Makthar", "Sufetula"),
            correctAnswerIndex = 0,
            categoryId = 1,
            fact = "Bulla Regia features complete underground levels of villas with well-preserved mosaics.",
            imageRes = R.drawable.bulla_regia
        ),
        Question(
            id = 4,
            text = "Where are the Antonine Baths, the largest Roman baths outside of Rome, located?",
            options = listOf("Sousse", "Kairouan", "Carthage", "Bizerte"),
            correctAnswerIndex = 2,
            categoryId = 1,
            fact = "The Antonine Baths were built during the reign of Roman Emperor Antoninus Pius.",
            imageRes = R.drawable.carthage
        ),
        Question(
            id = 5,
            text = "Which structure supplied water to ancient Carthage over a distance of more than 130 km?",
            options = listOf("El Jem Aqueduct", "Zaghouan Aqueduct", "Utica Aqueduct", "Dougga Aqueduct"),
            correctAnswerIndex = 1,
            categoryId = 1,
            fact = "The Zaghouan Aqueduct was one of the longest aqueducts in the Roman Empire.",
            imageRes = R.drawable.zaghouan_aqueduct
        ),
        Question(
            id = 6,
            text = "Sbeitla is famous for its well-preserved Roman ruins which feature three adjacent...",
            options = listOf("Amphitheaters", "Baths", "Temples", "Markets"),
            correctAnswerIndex = 2,
            categoryId = 1,
            fact = "The three temples in Sbeitla's Capitol were dedicated to Jupiter, Juno, and Minerva.",
            imageRes = R.drawable.sbeitla
        ),
        Question(
            id = 7,
            text = "Which Roman colony features a well-preserved amphitheater partly built into a hill?",
            options = listOf("Uthina (Oudna)", "Thuburbo Majus", "Makthar", "Bulla Regia"),
            correctAnswerIndex = 0,
            categoryId = 1,
            fact = "Uthina became a colony of Roman veterans under emperor Augustus.",
            imageRes = R.drawable.uthina
        ),
        Question(
            id = 8,
            text = "Which archaeological site in northern Tunisia is known for its impressive Capitol temple and Palaestra of the Petronii?",
            options = listOf("Dougga", "Thuburbo Majus", "Utica", "Sbeitla"),
            correctAnswerIndex = 1,
            categoryId = 1,
            fact = "Thuburbo Majus was originally a Punic town before becoming a Roman colony.",
            imageRes = R.drawable.thuburbo_majus
        ),
        Question(
            id = 9,
            text = "Which city was the first capital of the Roman province of Africa before Carthage took over?",
            options = listOf("Utica", "Hadrumetum (Sousse)", "Thysdrus (El Jem)", "Zama"),
            correctAnswerIndex = 0,
            categoryId = 1,
            fact = "Utica allied with Rome during the Third Punic War, making it the initial provincial capital.",
            imageRes = R.drawable.utica
        ),
        Question(
            id = 10,
            text = "Which Roman site features the impressive Arch of Trajan?",
            options = listOf("Sbeitla", "Dougga", "Makthar", "Bulla Regia"),
            correctAnswerIndex = 2,
            categoryId = 1,
            fact = "Makthar was originally a Numidian fortress before its romanization.",
            imageRes = R.drawable.makthar
        )
    )

    fun getQuestionsForCategory(categoryId: Int): List<Question> {
        return when (categoryId) {
            1 -> romanHeritageQuestions
            else -> emptyList()
        }
    }
}
