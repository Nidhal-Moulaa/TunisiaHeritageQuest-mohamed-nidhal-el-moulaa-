package com.example.mohamednidhalelmoulaa.data

data class Category(
    val id: String,
    val name: String,
    val questionCount: Int,
    val enabled: Boolean = true
)