package com.example.mohamednidhalelmoulaa.data

data class Question(
    val imageResId: Int,              // drawable resource ID
    val questionText: String,
    val options: List<String>,
    val correctAnswerIndex: Int,      // 0-based index of correct option
    val fact: String                  // shown after answer
)