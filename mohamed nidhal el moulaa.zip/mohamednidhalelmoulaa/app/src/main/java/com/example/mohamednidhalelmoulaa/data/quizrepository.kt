package com.example.mohamednidhalelmoulaa.data

import com.example.mohamednidhalelmoulaa.R

object QuizRepository {

    fun getCategories(): List<Category> = listOf(
        Category("roman", "Roman", 12, enabled = true),
        Category("islamic", "Islamic", 10, enabled = false),
        Category("punic", "Punic", 6, enabled = false),
        Category("modern", "Modern", 8, enabled = false),
        Category("nature", "Nature", 5, enabled = false),
        Category("cities", "Cities", 10, enabled = false)
    )

    fun getQuestionsForCategory(categoryId: String): List<Question> {
        return when (categoryId) {
            "roman" -> listOf(
                Question(
                    imageResId = R.drawable.el_jem,
                    questionText = "What is the name of this monument?",
                    options = listOf("Amphitheater of El Jem", "Dougga", "Carthage", "Bulla Regia"),
                    correctAnswerIndex = 0,
                    fact = "Built in 238 AD, this is the 3rd largest Roman amphitheater in the world."
                ),
                Question(
                    imageResId = R.drawable.dogga,
                    questionText = "Identify this UNESCO site.",
                    options = listOf("Sbeitla", "Dougga", "Thugga", "Maktar"),
                    correctAnswerIndex = 1,
                    fact = "Dougga is the best preserved Roman small town in North Africa."
                ),
                Question(
                    imageResId = R.drawable.carthage,
                    questionText = "Which ancient city is this?",
                    options = listOf("Utica", "Carthage", "Hadrumetum", "Thapsus"),
                    correctAnswerIndex = 1,
                    fact = "Carthage was the capital of Hannibal's empire."
                ),
                Question(
                    imageResId = R.drawable.bulla_regia,
                    questionText = "What is this underground Roman house site?",
                    options = listOf("Pupput", "Bulla Regia", "Thuburbo Majus", "Chemtou"),
                    correctAnswerIndex = 1,
                    fact = "Bulla Regia is famous for its underground villas."
                ),
                
            )
            else -> emptyList()
        }
    }
}