package com.example.mohamednidhalelmoulaa.model

enum class Difficulty(val timeLimit: Int?) {
    EASY(null), // No timer
    MEDIUM(15), // 15 seconds
    HARD(10)    // 10 seconds
}

data class Category(
    val id: Int,
    val name: String,
    val description: String,
    val iconRes: Int? = null // Placeholder for an icon resource ID
)

data class Question(
    val id: Int,
    val text: String,
    val options: List<String>,
    val correctAnswerIndex: Int,
    val imageRes: Int? = null, // Placeholder for an image resource ID
    val categoryId: Int,
    val fact: String = "" // Interesting fact shown after answering
)

data class GameState(
    val questions: List<Question> = emptyList(),
    val currentQuestionIndex: Int = 0,
    val score: Int = 0,
    val isGameOver: Boolean = false,
    val timeRemaining: Int? = null,
    val difficulty: Difficulty = Difficulty.MEDIUM,
    val selectedCategory: Category? = null,
    val isAnswerEvaluated: Boolean = false,
    val selectedAnswerIndex: Int? = null
) {
    val currentQuestion: Question?
        get() = questions.getOrNull(currentQuestionIndex)
}
