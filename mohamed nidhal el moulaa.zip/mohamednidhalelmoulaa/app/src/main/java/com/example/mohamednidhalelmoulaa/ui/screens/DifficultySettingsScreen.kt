package com.example.mohamednidhalelmoulaa.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mohamednidhalelmoulaa.model.Difficulty

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DifficultySettingsScreen(onDifficultySelected: (Difficulty) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Select Difficulty", color = MaterialTheme.colorScheme.onPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                DifficultyButton(
                    text = "Easy (No Timer)",
                    difficulty = Difficulty.EASY,
                    onClick = { onDifficultySelected(Difficulty.EASY) }
                )
                Spacer(modifier = Modifier.height(24.dp))
                DifficultyButton(
                    text = "Medium (15s Timer)",
                    difficulty = Difficulty.MEDIUM,
                    onClick = { onDifficultySelected(Difficulty.MEDIUM) }
                )
                Spacer(modifier = Modifier.height(24.dp))
                DifficultyButton(
                    text = "Hard (10s Timer)",
                    difficulty = Difficulty.HARD,
                    onClick = { onDifficultySelected(Difficulty.HARD) }
                )
            }
        }
    }
}

@Composable
fun DifficultyButton(text: String, difficulty: Difficulty, onClick: () -> Unit) {
    val containerColor = when (difficulty) {
        Difficulty.EASY -> MaterialTheme.colorScheme.tertiary
        Difficulty.MEDIUM -> MaterialTheme.colorScheme.secondary
        Difficulty.HARD -> MaterialTheme.colorScheme.primary
    }
    
    val textColor = when (difficulty) {
        Difficulty.EASY -> MaterialTheme.colorScheme.onPrimary
        Difficulty.MEDIUM -> MaterialTheme.colorScheme.onPrimary
        Difficulty.HARD -> MaterialTheme.colorScheme.onPrimary
    }

    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        colors = ButtonDefaults.buttonColors(containerColor = containerColor, contentColor = textColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(text = text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}
