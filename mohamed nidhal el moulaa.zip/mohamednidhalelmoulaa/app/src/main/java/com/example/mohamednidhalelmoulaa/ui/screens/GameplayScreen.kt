package com.example.mohamednidhalelmoulaa.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import com.example.mohamednidhalelmoulaa.model.Difficulty
import com.example.mohamednidhalelmoulaa.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameplayScreen(
    viewModel: GameViewModel,
    onGameOver: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    
    LaunchedEffect(uiState.isGameOver) {
        if (uiState.isGameOver) {
            onGameOver()
        }
    }

    val currentQuestion = uiState.currentQuestion ?: return

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "Question ${uiState.currentQuestionIndex + 1}/${uiState.questions.size}", 
                        color = MaterialTheme.colorScheme.onPrimary
                    ) 
                },
                actions = {
                    Text(
                        text = "Score: ${uiState.score}",
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(end = 16.dp),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Timer Display
            if (uiState.difficulty != Difficulty.EASY) {
                val timeColor = if ((uiState.timeRemaining ?: 0) <= 5) Color.Red else MaterialTheme.colorScheme.onBackground
                Text(
                    text = "Time: ${uiState.timeRemaining ?: 0}s",
                    color = timeColor,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            // Image Display
            if (currentQuestion.imageRes != null) {
                Image(
                    painter = painterResource(id = currentQuestion.imageRes),
                    contentDescription = "Question Image",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                // Image Placeholder
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .background(Color.LightGray, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Image Placeholder\n(Add Image Here)",
                        textAlign = TextAlign.Center,
                        color = Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Question Text
            Text(
                text = currentQuestion.text,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Options
            currentQuestion.options.forEachIndexed { index, optionText ->
                val isSelected = uiState.selectedAnswerIndex == index
                val isCorrect = index == currentQuestion.correctAnswerIndex
                
                val backgroundColor = when {
                    !uiState.isAnswerEvaluated -> MaterialTheme.colorScheme.surface
                    isCorrect -> Color(0xFF4CAF50) // Green for correct
                    isSelected && !isCorrect -> Color(0xFFF44336) // Red for wrong
                    else -> MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                }

                val textColor = when {
                    !uiState.isAnswerEvaluated -> MaterialTheme.colorScheme.onSurface
                    isCorrect || (isSelected && !isCorrect) -> Color.White
                    else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                }

                Button(
                    onClick = { viewModel.submitAnswer(index) },
                    enabled = !uiState.isAnswerEvaluated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = backgroundColor,
                        contentColor = textColor,
                        disabledContainerColor = backgroundColor,
                        disabledContentColor = textColor
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = optionText, fontSize = 16.sp)
                }
            }

            // Fact & Next Button
            if (uiState.isAnswerEvaluated) {
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Did you know?\n${currentQuestion.fact}",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = { viewModel.nextQuestion() },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Next Question", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
