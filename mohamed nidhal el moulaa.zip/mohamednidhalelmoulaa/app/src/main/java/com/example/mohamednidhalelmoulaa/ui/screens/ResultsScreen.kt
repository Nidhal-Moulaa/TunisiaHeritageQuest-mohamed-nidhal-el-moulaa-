package com.example.mohamednidhalelmoulaa.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mohamednidhalelmoulaa.model.Difficulty

@Composable
fun ResultsScreen(
    score: Int,
    totalQuestions: Int,
    difficulty: Difficulty,
    onPlayAgain: () -> Unit,
    onReturnToMenu: () -> Unit
) {
    val maxPossibleScore = when (difficulty) {
        Difficulty.EASY -> totalQuestions * 10
        Difficulty.MEDIUM -> totalQuestions * 15
        Difficulty.HARD -> totalQuestions * 20
    }
    
    val percentage = if (maxPossibleScore > 0) (score.toFloat() / maxPossibleScore.toFloat()) * 100 else 0f
    
    val (message, icon, iconColor) = when {
        percentage >= 80 -> Triple("Outstanding! You're a true historian.", Icons.Default.EmojiEvents, Color(0xFFFFD700)) // Gold
        percentage >= 50 -> Triple("Good job! Keep exploring.", Icons.Default.SentimentSatisfied, MaterialTheme.colorScheme.secondary)
        else -> Triple("Keep trying! There's much more to learn.", Icons.Default.SentimentSatisfied, MaterialTheme.colorScheme.onBackground)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = "Result Icon",
                tint = iconColor,
                modifier = Modifier.size(120.dp)
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "Quiz Completed!",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Your Score",
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Text(
                text = "$score / $maxPossibleScore",
                fontSize = 48.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.secondary
            )
            
            Text(
                text = "${percentage.toInt()}%",
                fontSize = 24.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.tertiary
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = message,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            Button(
                onClick = onPlayAgain,
                modifier = Modifier.width(200.dp).height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Play Again", fontSize = 18.sp)
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = onReturnToMenu,
                modifier = Modifier.width(200.dp).height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Main Menu", fontSize = 18.sp)
            }
        }
    }
}
