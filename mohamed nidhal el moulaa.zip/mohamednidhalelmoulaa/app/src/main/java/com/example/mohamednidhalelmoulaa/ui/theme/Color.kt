package com.example.mohamednidhalelmoulaa.ui.theme

import androidx.compose.ui.graphics.Color

val MediterraneanBlue = Color(0xFF003366)
val EarthToneWarm = Color(0xFFC2B280)
val SandLight = Color(0xFFEEDC9A)
val DeepBrown = Color(0xFF4A3B2C)
val AccentOrange = Color(0xFFE07A5F)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)