package com.example.mohamednidhalelmoulaa.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mohamednidhalelmoulaa.data.GameRepository
import com.example.mohamednidhalelmoulaa.model.Category
import com.example.mohamednidhalelmoulaa.model.Difficulty
import com.example.mohamednidhalelmoulaa.model.GameState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class GameViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(GameState())
    val uiState: StateFlow<GameState> = _uiState.asStateFlow()

    private var timerJob: Job? = null

    fun selectCategory(category: Category) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun selectDifficulty(difficulty: Difficulty) {
        _uiState.update { it.copy(difficulty = difficulty) }
    }

    fun startGame() {
        val selectedCategory = _uiState.value.selectedCategory ?: return
        val questions = GameRepository.getQuestionsForCategory(selectedCategory.id).shuffled()
        
        _uiState.update { 
            GameState(
                questions = questions,
                difficulty = it.difficulty,
                selectedCategory = selectedCategory,
                timeRemaining = it.difficulty.timeLimit
            ) 
        }
        startTimer()
    }

    private fun startTimer() {
        timerJob?.cancel()
        val timeLimit = _uiState.value.difficulty.timeLimit
        if (timeLimit != null) {
            _uiState.update { it.copy(timeRemaining = timeLimit) }
            timerJob = viewModelScope.launch {
                while ((_uiState.value.timeRemaining ?: 0) > 0 && !_uiState.value.isAnswerEvaluated) {
                    delay(1000)
                    _uiState.update { 
                        it.copy(timeRemaining = (it.timeRemaining ?: 1) - 1) 
                    }
                }
                if ((_uiState.value.timeRemaining ?: 0) <= 0 && !_uiState.value.isAnswerEvaluated) {
                    // Time's up
                    _uiState.update { it.copy(isAnswerEvaluated = true, selectedAnswerIndex = -1) }
                }
            }
        }
    }

    fun submitAnswer(answerIndex: Int) {
        if (_uiState.value.isAnswerEvaluated) return
        timerJob?.cancel()
        
        val isCorrect = answerIndex == _uiState.value.currentQuestion?.correctAnswerIndex
        val points = if (isCorrect) {
            when (_uiState.value.difficulty) {
                Difficulty.EASY -> 10
                Difficulty.MEDIUM -> 15
                Difficulty.HARD -> 20
            }
        } else {
            0
        }

        _uiState.update { 
            it.copy(
                isAnswerEvaluated = true,
                selectedAnswerIndex = answerIndex,
                score = it.score + points
            ) 
        }
    }

    fun nextQuestion() {
        val currentState = _uiState.value
        if (currentState.currentQuestionIndex < currentState.questions.size - 1) {
            _uiState.update { 
                it.copy(
                    currentQuestionIndex = it.currentQuestionIndex + 1,
                    isAnswerEvaluated = false,
                    selectedAnswerIndex = null
                ) 
            }
            startTimer()
        } else {
            _uiState.update { it.copy(isGameOver = true) }
        }
    }

    fun resetGame() {
        timerJob?.cancel()
        _uiState.value = GameState()
    }
}
