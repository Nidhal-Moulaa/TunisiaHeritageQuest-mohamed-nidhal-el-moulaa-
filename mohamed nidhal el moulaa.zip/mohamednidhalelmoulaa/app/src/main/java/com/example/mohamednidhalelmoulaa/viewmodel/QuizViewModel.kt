package com.example.mohamednidhalelmoulaa.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mohamednidhalelmoulaa.data.Question
import com.example.mohamednidhalelmoulaa.data.QuizRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class QuizViewModel : ViewModel() {


    var difficulty by mutableStateOf("easy")
        private set
    var timerEnabled by mutableStateOf(true)
    var soundEnabled by mutableStateOf(true)
    var hapticEnabled by mutableStateOf(true)

    private lateinit var questions: List<Question>
    var currentQuestionIndex by mutableIntStateOf(0)
        private set
    var currentQuestion by mutableStateOf<Question?>(null)
        private set
    var score by mutableIntStateOf(0)
        private set


    var remainingSeconds by mutableIntStateOf(15)
        private set
    private var timerJob: Job? = null

    // Answer tracking
    var answered by mutableStateOf(false)
    var selectedAnswerIndex by mutableIntStateOf(-1)
    var showResult by mutableStateOf(false)
    var isCorrect by mutableStateOf(false)

    fun initGame(categoryId: String, difficulty: String, timerEnabled: Boolean) {
        questions = QuizRepository.getQuestionsForCategory(categoryId)
        this.difficulty = difficulty
        this.timerEnabled = timerEnabled
        currentQuestionIndex = 0
        score = 0
        showResult = false
        answered = false
        if (questions.isNotEmpty()) {
            currentQuestion = questions[0]
            startTimer()
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        if (!timerEnabled) {
            remainingSeconds = 0
            return
        }
        val seconds = when (difficulty) {
            "easy" -> 15
            "medium" -> 20
            "hard" -> 15
            else -> 15
        }
        remainingSeconds = seconds
        timerJob = viewModelScope.launch {
            while (remainingSeconds > 0) {
                delay(1000L)
                remainingSeconds--
            }
            if (!answered) {
                submitAnswer(-1)
            }
        }
    }

    fun submitAnswer(optionIndex: Int) {
        if (answered || currentQuestion == null) return
        answered = true
        timerJob?.cancel()
        selectedAnswerIndex = optionIndex
        val correctIndex = currentQuestion!!.correctAnswerIndex
        isCorrect = (optionIndex == correctIndex)
        if (isCorrect) score += 10
        showResult = true
    }

    fun nextQuestion() {
        if (currentQuestionIndex < questions.size - 1) {
            currentQuestionIndex++
            currentQuestion = questions[currentQuestionIndex]
            answered = false
            showResult = false
            selectedAnswerIndex = -1
            startTimer()
        }
    }

    fun isLastQuestion(): Boolean = currentQuestionIndex == questions.size - 1

    fun getTotalQuestions(): Int = questions.size

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}