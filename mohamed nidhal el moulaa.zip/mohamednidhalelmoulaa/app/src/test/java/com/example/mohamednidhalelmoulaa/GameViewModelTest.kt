package com.example.mohamednidhalelmoulaa

import com.example.mohamednidhalelmoulaa.model.Difficulty
import com.example.mohamednidhalelmoulaa.data.GameRepository
import com.example.mohamednidhalelmoulaa.viewmodel.GameViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class GameViewModelTest {

    private lateinit var viewModel: GameViewModel

    @Before
    fun setup() {
        viewModel = GameViewModel()
    }

    @Test
    fun `test game starts correctly`() {
        // Arrange
        val category = GameRepository.categories[0] // Roman Heritage
        viewModel.selectCategory(category)
        viewModel.selectDifficulty(Difficulty.MEDIUM)

        // Act
        viewModel.startGame()

        // Assert
        val state = viewModel.uiState.value
        assertEquals(category, state.selectedCategory)
        assertEquals(Difficulty.MEDIUM, state.difficulty)
        assertEquals(15, state.timeRemaining)
        assertTrue(state.questions.isNotEmpty())
        assertEquals(0, state.score)
        assertEquals(0, state.currentQuestionIndex)
        assertFalse(state.isGameOver)
    }

    @Test
    fun `test submitting correct answer increases score`() {
        // Arrange
        val category = GameRepository.categories[0]
        viewModel.selectCategory(category)
        viewModel.selectDifficulty(Difficulty.EASY)
        viewModel.startGame()

        val currentQuestion = viewModel.uiState.value.currentQuestion
        assertNotNull(currentQuestion)
        val correctAnswerIndex = currentQuestion!!.correctAnswerIndex

        // Act
        viewModel.submitAnswer(correctAnswerIndex)

        // Assert
        val state = viewModel.uiState.value
        assertEquals(10, state.score) // Easy difficulty correct answer = 10 points
        assertTrue(state.isAnswerEvaluated)
        assertEquals(correctAnswerIndex, state.selectedAnswerIndex)
    }

    @Test
    fun `test submitting wrong answer does not increase score`() {
        // Arrange
        val category = GameRepository.categories[0]
        viewModel.selectCategory(category)
        viewModel.selectDifficulty(Difficulty.EASY)
        viewModel.startGame()

        val currentQuestion = viewModel.uiState.value.currentQuestion
        assertNotNull(currentQuestion)
        // Pick an index that is not the correct answer
        val wrongAnswerIndex = if (currentQuestion!!.correctAnswerIndex == 0) 1 else 0

        // Act
        viewModel.submitAnswer(wrongAnswerIndex)

        // Assert
        val state = viewModel.uiState.value
        assertEquals(0, state.score)
        assertTrue(state.isAnswerEvaluated)
        assertEquals(wrongAnswerIndex, state.selectedAnswerIndex)
    }

    @Test
    fun `test moving to next question updates index`() {
        // Arrange
        val category = GameRepository.categories[0]
        viewModel.selectCategory(category)
        viewModel.selectDifficulty(Difficulty.MEDIUM)
        viewModel.startGame()
        viewModel.submitAnswer(0) // Submit some answer

        // Act
        viewModel.nextQuestion()

        // Assert
        val state = viewModel.uiState.value
        assertEquals(1, state.currentQuestionIndex)
        assertFalse(state.isAnswerEvaluated)
    }
}
